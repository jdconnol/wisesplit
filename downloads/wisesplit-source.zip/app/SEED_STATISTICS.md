# 📊 Seeding Statistics Report

Generated at: 2026-06-16T07:28:54.550Z

## 📈 Overview

| Metric | Value |
|--------|-------|
| Total Users | 150 |
| Total Groups | 150 |
| Total Expenses | 13,147 |

## 👥 Group Analysis

| Metric | Value |
|--------|-------|
| Avg Groups per User | 6.15 |
| Avg Group Size | 6.15 members |
### Group Type Distribution
- household: 45 (30.0%)
- trip: 40 (26.7%)
- job: 48 (32.0%)
- friends: 17 (11.3%)
## 🔗 Social Graph Analysis

| Metric | Value |
|--------|-------|
| Total Unique Connections | 3,180 |
| Avg Connections per User | 42.40 |
| Max Connectivity | 68 connections |
| Min Connectivity | 0 connections |
| Users without Friends | 0 (0.0%) |

## ⭐ Most Connected Users

| # | Email | Connections | Groups |
|---|-------|-------------|--------|
| 1 | johnathon.moore12@example.net | 68 | 11 |
| 2 | toney.swaniawski45@example.org | 67 | 10 |
| 3 | demario.pacocha@example.com | 66 | 11 |
## 📊 Least Connected Users

| # | Email | Connections | Groups |
|---|-------|-------------|--------|
| 1 | jameson_yost@example.net | 10 | 1 |
| 2 | adrain.weissnat67@example.com | 20 | 3 |
| 3 | danika_goyette44@example.org | 20 | 2 |
## 🌍 Most Connected Users by Currency

### USD

| # | Email | Connections | Groups |
|---|-------|-------------|--------|
| 1 | johnathon.moore12@example.net | 68 | 11 |
| 2 | toney.swaniawski45@example.org | 67 | 10 |
| 3 | demario.pacocha@example.com | 66 | 11 |
### EUR

| # | Email | Connections | Groups |
|---|-------|-------------|--------|
| 1 | estevan.okeefe6@example.com | 61 | 11 |
| 2 | tanner_mcglynn93@example.org | 59 | 10 |
| 3 | fannie_keebler@example.net | 59 | 10 |
### BHD

| # | Email | Connections | Groups |
|---|-------|-------------|--------|
| 1 | dandre.rice79@example.org | 46 | 7 |
| 2 | angelica_runolfsdottir@example.org | 43 | 6 |
| 3 | julius_brown32@example.org | 43 | 4 |
### GBP

| # | Email | Connections | Groups |
|---|-------|-------------|--------|
| 1 | corine_kassulke5@example.org | 60 | 8 |
| 2 | jaylin.luettgen27@example.net | 53 | 8 |
| 3 | janis.rodriguez@example.net | 52 | 10 |
### JPY

| # | Email | Connections | Groups |
|---|-------|-------------|--------|
| 1 | rafael_kemmer54@example.org | 61 | 9 |
| 2 | shyanne_block47@example.com | 32 | 3 |
### CHF

| # | Email | Connections | Groups |
|---|-------|-------------|--------|
| 1 | rogers_farrell@example.net | 46 | 6 |
| 2 | eusebio_purdy61@example.net | 37 | 4 |
## 💰 Expense Analysis

| Metric | Value |
|--------|-------|
| Total Amount | 9751708.77 |
| Avg Expense Amount | 741.74 |
| Expenses per User (avg) | 386.1 |
| Expenses per User (max) | 1215 |
| Expenses per User (min) | 0 |
| Users without Expenses | 0 (0.0%) |
| Groups without Expenses | 0 (0.0%) |

## 💵 Expenses by Currency

| Currency | Count | Percentage |
|----------|-------|-----------|
| USD | 8,534 | 64.9% |
| GBP | 2,233 | 17.0% |
| EUR | 1,482 | 11.3% |
| BHD | 372 | 2.8% |
| JPY | 268 | 2.0% |
| CHF | 258 | 2.0% |
## 📂 Expenses by Category

| Category | Count | Percentage |
|----------|-------|-----------|
| food | 4,171 | 31.7% |
| utilities | 2,390 | 18.2% |
| travel | 2,290 | 17.4% |
| entertainment | 1,706 | 13.0% |
| home | 1,691 | 12.9% |
| life | 806 | 6.1% |
| general | 93 | 0.7% |
## 🔀 Split Type Distribution

| Split Type | Count | Percentage | Distribution |
|------------|-------|-----------|--------------|
| EQUAL | 7,754 | 59.0% | ████████████ |
| EXACT | 2,036 | 15.5% | ███ |
| PERCENTAGE | 2,003 | 15.2% | ███ |
| SHARE | 680 | 5.2% | █ |
| ADJUSTMENT | 674 | 5.1% | █ |